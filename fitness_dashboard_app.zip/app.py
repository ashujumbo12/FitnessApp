import streamlit as st
from db import init_db, get_session
from models import User
import os

st.set_page_config(page_title="Fitness Progress", page_icon="📈", layout="wide")
with open("assets/style.css") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

init_db()

# Simple local 'profile' bootstrap
def bootstrap_user():
    from sqlmodel import select
    with get_session() as sess:
        u = sess.exec(select(User)).first()
        if not u:
            u = User(name="You", email=None, height_cm=None, goal_weight_kg=None)
            sess.add(u); sess.commit(); sess.refresh(u)
        return u

user = bootstrap_user()
st.sidebar.header("Profile")
with st.sidebar:
    with st.form("profile_form"):
        name = st.text_input("Name", user.name or "You")
        height = st.number_input("Height (cm)", value=float(user.height_cm) if user.height_cm else 0.0, min_value=0.0, step=0.5)
        goal = st.number_input("Goal weight (kg)", value=float(user.goal_weight_kg) if user.goal_weight_kg else 0.0, min_value=0.0, step=0.1)
        units = st.selectbox("Units", ["metric","imperial"], index=0 if user.units=="metric" else 1)
        if st.form_submit_button("Save profile"):
            with get_session() as sess:
                user.name, user.height_cm, user.goal_weight_kg, user.units = name, (height or None), (goal or None), units
                sess.add(user); sess.commit()
            st.success("Profile saved")

st.title("📈 Fitness Progress — Home")
st.write("Use the tabs in the left sidebar (Pages) to add entries and explore your dashboard.")

st.markdown('<div class="card">', unsafe_allow_html=True)
st.subheader("Getting started")
st.markdown("""
1. Go to **Data Entry** to log your **Daily** (weight/steps) and **Weekly** (measurements, scores) data.
2. Open **Dashboard** to see KPIs, trends, and comparisons.
3. Import your existing sheet via **Import/Export**.
""")
st.markdown('</div>', unsafe_allow_html=True)

st.caption("All data stays on your machine (SQLite).")
