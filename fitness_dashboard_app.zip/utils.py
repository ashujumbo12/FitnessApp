from __future__ import annotations
from typing import Optional
import pandas as pd
from sqlalchemy import select, func
from sqlmodel import Session
from models import DailyMetric, Week, Measurement, Wellbeing, Adherence

def load_daily_df(sess: Session, user_id: int) -> pd.DataFrame:
    q = select(DailyMetric).where(DailyMetric.user_id==user_id)
    rows = sess.exec(q).all()
    df = pd.DataFrame([r.model_dump() for r in rows])
    if not df.empty:
        df['date'] = pd.to_datetime(df['date'])
    return df

def load_weekly_df(sess: Session, user_id: int) -> pd.DataFrame:
    # joins on week
    d = load_daily_df(sess, user_id)
    if d.empty:
        return pd.DataFrame()
    w = pd.DataFrame([w.model_dump() for w in sess.exec(select(Week).where(Week.user_id==user_id)).all()])
    m = pd.DataFrame([m.model_dump() for m in sess.exec(select(Measurement).where(Measurement.user_id==user_id)).all()])
    wb = pd.DataFrame([x.model_dump() for x in sess.exec(select(Wellbeing).where(Wellbeing.user_id==user_id)).all()])
    ad = pd.DataFrame([x.model_dump() for x in sess.exec(select(Adherence).where(Adherence.user_id==user_id)).all()])
    # compute weekly avg weight and steps
    d['week_id'] = d['week_id']
    avg = d.groupby('week_id').agg(avg_weight_kg=('weight_kg','mean'), avg_steps=('steps','mean')).reset_index()
    out = avg.merge(w, left_on='week_id', right_on='id', how='left', suffixes=('','_wk'))
    for frame in [m, wb, ad]:
        if not frame.empty:
            out = out.merge(frame, left_on='week_id', right_on='week_id', how='left', suffixes=('',''))
    out = out.sort_values('week_number')
    out['weekly_weight_loss'] = out['avg_weight_kg'].diff(periods=1)
    return out

def rolling_avg(series, window: int = 7):
    return series.rolling(window=window, min_periods=1).mean()

