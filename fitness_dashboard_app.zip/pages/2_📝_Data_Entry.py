import streamlit as st
from datetime import date, timedelta
from sqlmodel import select
from db import get_session
from models import User, DailyMetric, Week, Measurement, Wellbeing, Adherence, Photo
import os

st.set_page_config(page_title="Data Entry", page_icon="📝", layout="wide")
with open("assets/style.css") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

st.title("📝 Data Entry")

with get_session() as sess:
    user = sess.exec(select(User)).first()

tabs = st.tabs(["Daily Entry", "Weekly Check-in", "Photos"])

with tabs[0]:
    st.subheader("Daily")
    with st.form("daily_form"):
        d = st.date_input("Date", value=date.today())
        weight = st.number_input("Weight (kg)", min_value=0.0, step=0.1)
        steps = st.number_input("Steps", min_value=0, step=100)
        run_km = st.number_input("Run/Walk (km)", min_value=0.0, step=0.1)
        submitted = st.form_submit_button("Save")
    if submitted:
        with get_session() as sess:
            # Find or create week for this date (week start = nearest Monday from date - date.weekday())
            start = d - timedelta(days=d.weekday())
            wk = sess.exec(select(Week).where(Week.user_id==user.id, Week.start_date==start)).first()
            if not wk:
                # compute week_number by counting existing weeks
                count = sess.exec(select(Week).where(Week.user_id==user.id)).all()
                wk = Week(user_id=user.id, week_number=len(count)+1, start_date=start)
                sess.add(wk); sess.commit(); sess.refresh(wk)
            # Upsert daily
            dm = sess.exec(select(DailyMetric).where(DailyMetric.user_id==user.id, DailyMetric.date==d)).first()
            if not dm:
                dm = DailyMetric(user_id=user.id, date=d, week_id=wk.id)
            dm.weight_kg = weight or None
            dm.steps = int(steps) if steps else None
            dm.run_km = run_km or None
            dm.week_id = wk.id
            sess.add(dm); sess.commit()
        st.success("Saved daily entry.")

with tabs[1]:
    st.subheader("Weekly Check-in")
    st.caption("Fill once per week (measurements in inches; scores as per scale).")
    with get_session() as sess:
        weeks = sess.exec(select(Week).where(Week.user_id==user.id).order_by(Week.start_date.desc())).all()
    week_options = {f"Week {w.week_number} — {w.start_date}": w for w in weeks}
    selected = st.selectbox("Select Week", list(week_options.keys())) if weeks else None
    if not weeks:
        st.info("No weeks found yet. Add a daily entry first to create a week.")
    else:
        wk = week_options[selected]
        col1, col2 = st.columns(2)
        with col1:
            with st.form("measurements_form"):
                st.markdown("**Measurements (inches)**")
                r_b = st.number_input("Right Biceps", min_value=0.0, step=0.1)
                l_b = st.number_input("Left Biceps", min_value=0.0, step=0.1)
                chest = st.number_input("Chest", min_value=0.0, step=0.1)
                r_t = st.number_input("Right Thigh", min_value=0.0, step=0.1)
                l_t = st.number_input("Left Thigh", min_value=0.0, step=0.1)
                waist = st.number_input("Waist @ Navel", min_value=0.0, step=0.1)
                if st.form_submit_button("Save Measurements"):
                    with get_session() as sess:
                        m = sess.exec(select(Measurement).where(Measurement.user_id==user.id, Measurement.week_id==wk.id)).first()
                        if not m: m = Measurement(user_id=user.id, week_id=wk.id)
                        m.r_biceps_in, m.l_biceps_in, m.chest_in = r_b or None, l_b or None, chest or None
                        m.r_thigh_in, m.l_thigh_in, m.waist_navel_in = r_t or None, l_t or None, waist or None
                        sess.add(m); sess.commit()
                    st.success("Saved measurements.")
        with col2:
            with st.form("scores_form"):
                st.markdown("**Wellbeing (0–5)**")
                sleep = st.slider("Sleep issues", 0, 5, 0)
                hunger = st.slider("Hunger issues", 0, 5, 0)
                stress = st.slider("Stress issues", 0, 5, 0)
                st.markdown("**Adherence (0–10)**")
                diet = st.slider("Diet adherence", 0, 10, 10)
                workout = st.slider("Workout adherence", 0, 10, 10)
                if st.form_submit_button("Save Scores"):
                    with get_session() as sess:
                        wb = sess.exec(select(Wellbeing).where(Wellbeing.user_id==user.id, Wellbeing.week_id==wk.id)).first()
                        if not wb: wb = Wellbeing(user_id=user.id, week_id=wk.id)
                        wb.sleep_issues, wb.hunger_issues, wb.stress_issues = sleep, hunger, stress
                        sess.add(wb)
                        ad = sess.exec(select(Adherence).where(Adherence.user_id==user.id, Adherence.week_id==wk.id)).first()
                        if not ad: ad = Adherence(user_id=user.id, week_id=wk.id)
                        ad.diet_score, ad.workout_score = diet, workout
                        sess.add(ad); sess.commit()
                    st.success("Saved scores.")

with tabs[2]:
    st.subheader("Progress Photos")
    with get_session() as sess:
        weeks = sess.exec(select(Week).where(Week.user_id==user.id).order_by(Week.start_date.desc())).all()
    week_options = {f"Week {w.week_number} — {w.start_date}": w for w in weeks}
    selected = st.selectbox("Select Week for Photos", list(week_options.keys())) if weeks else None
    if not weeks:
        st.info("No weeks found yet.")
    else:
        wk = week_options[selected]
        uploaded = st.file_uploader("Upload photos (front/back/side/pose)", accept_multiple_files=True, type=["png","jpg","jpeg","webp"])
        if uploaded and st.button("Save Photos"):
            saved = 0
            for file in uploaded:
                folder = os.path.join("data","photos", f"week_{wk.week_number}")
                os.makedirs(folder, exist_ok=True)
                path = os.path.join(folder, file.name)
                with open(path, "wb") as f:
                    f.write(file.read())
                # derive pose from filename keywords
                lower = file.name.lower()
                pose = "front"
                for key in ["back","side","most","mm","pose"]:
                    if key in lower:
                        pose = key; break
                with get_session() as sess:
                    p = Photo(user_id=user.id, week_id=wk.id, pose=pose, path=path)
                    sess.add(p); sess.commit()
                saved += 1
            st.success(f"Saved {saved} photo(s).")
