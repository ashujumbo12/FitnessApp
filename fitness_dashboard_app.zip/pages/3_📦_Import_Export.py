import streamlit as st
import pandas as pd
from datetime import date, timedelta
from dateutil.parser import parse as parse_date
from sqlmodel import select
from db import get_session
from models import User, DailyMetric, Week, Measurement, Wellbeing, Adherence
import io, os, shutil, sqlite3

st.set_page_config(page_title="Import/Export", page_icon="📦", layout="wide")
with open("assets/style.css") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

st.title("📦 Import / Export")

st.subheader("Import from CSV (Progress Sheet format)")
tmpl = pd.DataFrame({
    "week_number":[1],
    "start_date":["2025-01-06"],
    "date":["2025-01-06"],
    "weight_kg":[88.9],
    "steps":[12319],
    "r_biceps_in":[12.5],
    "l_biceps_in":[12.3],
    "chest_in":[40.0],
    "r_thigh_in":[22.0],
    "l_thigh_in":[21.8],
    "waist_navel_in":[36.5],
    "sleep_issues":[1],
    "hunger_issues":[2],
    "stress_issues":[1],
    "diet_score":[9],
    "workout_score":[8],
})
st.download_button("Download CSV Template", data=tmpl.to_csv(index=False), file_name="progress_template.csv")

uploaded = st.file_uploader("Upload CSV", type=["csv"])
if uploaded and st.button("Import"):
    df = pd.read_csv(uploaded)
    # Normalize column names
    df.columns = [c.strip().lower() for c in df.columns]
    required = ["date","weight_kg","steps","week_number","start_date"]
    if not set(required).issubset(set(df.columns)):
        st.error(f"Missing columns. Required: {required}")
    else:
        n_daily, n_week = 0, 0
        with get_session() as sess:
            user = sess.exec(select(User)).first()
            # Create or upsert weeks
            for _, row in df.iterrows():
                start = parse_date(str(row["start_date"])).date()
                wk = sess.exec(select(Week).where(Week.user_id==user.id, Week.start_date==start)).first()
                if not wk:
                    wk = Week(user_id=user.id, week_number=int(row["week_number"]), start_date=start)
                    sess.add(wk); sess.commit(); sess.refresh(wk); n_week += 1
                # daily
                d = parse_date(str(row["date"])).date()
                dm = sess.exec(select(DailyMetric).where(DailyMetric.user_id==user.id, DailyMetric.date==d)).first()
                if not dm: dm = DailyMetric(user_id=user.id, date=d, week_id=wk.id)
                dm.weight_kg = float(row["weight_kg"]) if not pd.isna(row["weight_kg"]) else None
                dm.steps = int(row["steps"]) if not pd.isna(row["steps"]) else None
                dm.week_id = wk.id
                sess.add(dm); sess.commit(); n_daily += 1
                # Optional weekly rows if present
                def assign_weekly(model_cls, fields):
                    existing = sess.exec(select(model_cls).where(model_cls.user_id==user.id, model_cls.week_id==wk.id)).first()
                    if not existing:
                        existing = model_cls(user_id=user.id, week_id=wk.id)
                    changed = False
                    for f in fields:
                        if f in df.columns and f in row and not pd.isna(row[f]):
                            setattr(existing, f, float(row[f]) if "score" not in f and "issues" not in f else int(row[f]))
                            changed = True
                    if changed:
                        sess.add(existing); sess.commit()
                assign_weekly(Measurement, ["r_biceps_in","l_biceps_in","chest_in","r_thigh_in","l_thigh_in","waist_navel_in"])
                assign_weekly(Wellbeing, ["sleep_issues","hunger_issues","stress_issues"])
                assign_weekly(Adherence, ["diet_score","workout_score"])
        st.success(f"Imported {n_daily} daily rows; created {n_week} weeks.")

st.subheader("Export / Backup")
col1, col2 = st.columns(2)
with col1:
    if st.button("Export all tables to CSV"):
        from models import DailyMetric, Week, Measurement, Wellbeing, Adherence
        with get_session() as sess:
            import tempfile, zipfile
            tables = {
                "daily_metrics.csv": pd.DataFrame([r.model_dump() for r in sess.exec(select(DailyMetric)).all()]),
                "weeks.csv": pd.DataFrame([r.model_dump() for r in sess.exec(select(Week)).all()]),
                "measurements.csv": pd.DataFrame([r.model_dump() for r in sess.exec(select(Measurement)).all()]),
                "wellbeing.csv": pd.DataFrame([r.model_dump() for r in sess.exec(select(Wellbeing)).all()]),
                "adherence.csv": pd.DataFrame([r.model_dump() for r in sess.exec(select(Adherence)).all()]),
            }
            zbuf = io.BytesIO()
            with zipfile.ZipFile(zbuf, "w", zipfile.ZIP_DEFLATED) as z:
                for name, df in tables.items():
                    z.writestr(name, df.to_csv(index=False))
            st.download_button("Download CSV bundle", data=zbuf.getvalue(), file_name="fitness_export.zip")
with col2:
    if st.button("Backup SQLite DB"):
        path = os.path.join("data","fitness.db")
        if os.path.exists(path):
            with open(path,"rb") as f:
                st.download_button("Download DB", data=f.read(), file_name="fitness.db")
        else:
            st.warning("No DB found yet.")
