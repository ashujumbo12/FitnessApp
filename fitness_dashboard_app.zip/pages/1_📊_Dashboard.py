import streamlit as st
import pandas as pd
from datetime import date
from sqlmodel import select
from db import get_session
from models import User, DailyMetric, Week, Measurement, Wellbeing, Adherence, Photo
from utils import load_daily_df, load_weekly_df, rolling_avg
import plotly.express as px

st.set_page_config(page_title="Dashboard", page_icon="📊", layout="wide")
with open("assets/style.css") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

st.title("📊 Dashboard")

with get_session() as sess:
    user = sess.exec(select(User)).first()
    daily = load_daily_df(sess, user.id)
    weekly = load_weekly_df(sess, user.id)

with st.sidebar:
    st.header("Filters")
    if not daily.empty:
        min_d, max_d = daily['date'].min().date(), daily['date'].max().date()
    else:
        min_d, max_d = date.today(), date.today()
    dr = st.date_input("Date range", value=(min_d, max_d))
    show_weight = st.checkbox("Show weight", True)
    show_steps = st.checkbox("Show steps", True)
    smooth = st.slider("Smoothing (days)", 1, 14, 7)
    show_weekly_loss = st.checkbox("Show weekly weight loss", True)
    step_goal = st.number_input("Steps goal", 10000, step=500, value=10000)
    adherence_min = st.slider("Min adherence (diet & workout)", 0, 10, 0)

if daily.empty:
    st.info("No data yet. Add entries in the Data Entry page.")
    st.stop()

# Apply date filter
mask = (daily['date'] >= pd.to_datetime(dr[0])) & (daily['date'] <= pd.to_datetime(dr[1]))
df = daily.loc[mask].sort_values('date')

kpi_cols = st.columns(4)
with kpi_cols[0]:
    st.markdown('<div class="card kpi">', unsafe_allow_html=True)
    st.markdown('<div class="label">Current Weight</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="value">{df["weight_kg"].dropna().iloc[-1] if df["weight_kg"].notna().any() else "—"} kg</div>', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)
with kpi_cols[1]:
    st.markdown('<div class="card kpi">', unsafe_allow_html=True)
    st.markdown('<div class="label">7-day Avg Steps</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="value">{int(rolling_avg(df["steps"].fillna(0),7).iloc[-1]) if df["steps"].notna().any() else "—"}</div>', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)
with kpi_cols[2]:
    st.markdown('<div class="card kpi">', unsafe_allow_html=True)
    # weekly loss from weekly df if available
    if not weekly.empty and weekly['weekly_weight_loss'].notna().any():
        last_loss = weekly['weekly_weight_loss'].iloc[-1]
        text = f"{last_loss:.2f} kg" if pd.notna(last_loss) else "—"
    else:
        text = "—"
    st.markdown('<div class="label">Last Week Change</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="value">{text}</div>', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)
with kpi_cols[3]:
    st.markdown('<div class="card kpi">', unsafe_allow_html=True)
    good_days = int((df['steps'] >= step_goal).sum())
    st.markdown('<div class="label">Days ≥ Step Goal</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="value">{good_days}</div>', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)

# Charts
if show_weight and df['weight_kg'].notna().any():
    s = rolling_avg(df.set_index('date')['weight_kg'], window=smooth).reset_index()
    fig = px.line(s, x='date', y='weight_kg', title="Daily Weight (smoothed)")
    st.plotly_chart(fig, use_container_width=True)

if show_steps and df['steps'].notna().any():
    fig = px.bar(df, x='date', y='steps', title="Daily Steps")
    st.plotly_chart(fig, use_container_width=True)

if not weekly.empty:
    # filter on adherence
    weekly_f = weekly.copy()
    weekly_f = weekly_f[(weekly_f['diet_score'].fillna(10) >= adherence_min) & (weekly_f['workout_score'].fillna(10) >= adherence_min)]
    cols = st.columns(2)
    with cols[0]:
        fig = px.line(weekly_f, x='week_number', y='avg_weight_kg', markers=True, title="Avg Weight by Week")
        st.plotly_chart(fig, use_container_width=True)
    with cols[1]:
        fig = px.bar(weekly_f, x='week_number', y='avg_steps', title="Avg Steps by Week")
        st.plotly_chart(fig, use_container_width=True)

    cols2 = st.columns(2)
    with cols2[0]:
        if show_weekly_loss and weekly_f['weekly_weight_loss'].notna().any():
            fig = px.bar(weekly_f, x='week_number', y='weekly_weight_loss', title="Weekly Weight Change (kg)")
            st.plotly_chart(fig, use_container_width=True)
    with cols2[1]:
        # measurements - waist & chest trend
        meas_cols = ['waist_navel_in','chest_in','r_biceps_in','r_thigh_in']
        mdf = weekly_f[['week_number'] + [c for c in meas_cols if c in weekly_f.columns]]
        mdf = mdf.dropna(how='all', axis=1)
        if mdf.shape[1] > 1:
            mdf_long = mdf.melt(id_vars='week_number', var_name='metric', value_name='value')
            fig = px.line(mdf_long, x='week_number', y='value', color='metric', markers=True, title="Measurements (inches)")
            st.plotly_chart(fig, use_container_width=True)

    # wellbeing & adherence
    cols3 = st.columns(2)
    with cols3[0]:
        wb_cols = ['sleep_issues','hunger_issues','stress_issues']
        wdf = weekly_f[['week_number'] + [c for c in wb_cols if c in weekly_f.columns]]
        if wdf.shape[1] > 1:
            wdf_long = wdf.melt(id_vars='week_number', var_name='metric', value_name='value')
            fig = px.bar(wdf_long, x='week_number', y='value', color='metric', barmode='group', title="Wellbeing (0–5)")
            st.plotly_chart(fig, use_container_width=True)
    with cols3[1]:
        ad_cols = ['diet_score','workout_score']
        adf = weekly_f[['week_number'] + [c for c in ad_cols if c in weekly_f.columns]]
        if adf.shape[1] > 1:
            adf_long = adf.melt(id_vars='week_number', var_name='metric', value_name='value')
            fig = px.bar(adf_long, x='week_number', y='value', color='metric', barmode='group', title="Adherence (0–10)")
            st.plotly_chart(fig, use_container_width=True)
